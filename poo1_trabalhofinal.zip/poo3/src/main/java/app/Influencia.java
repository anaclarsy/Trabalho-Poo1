package app;

// Interface Influencia
public interface Influencia {
    String getInfluencias();
}
